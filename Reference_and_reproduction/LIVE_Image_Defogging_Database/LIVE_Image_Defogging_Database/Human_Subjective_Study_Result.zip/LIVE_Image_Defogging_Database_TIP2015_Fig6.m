%% TIP 2015, 
% Figure 6. Code
% (a) MOS of 100 test images. 
% (b) Associated histogram of MOS scores. 
% (c) MOS standard deviation histogram.
%
% Reference: 
% L. K. Choi, J. You, and A. C. Bovik, 
% "Referenceless Prediction of Perceptual Fog Density and Perceptual Image Defogging," 
% IEEE Transactions on Image Processing, vol. 24, no. 11, pp. 3888-3901, Nov. 2015.

clear all; close all; clc; 
%% Load subjective study data

    load('LIVE_Image_Defogging_Database.mat');

%% Fig.6 (a)
% MOS of 100 test images. 

    set(0,'DefaultAxesFontSize',16);
    lw = 1.3; 
    figure; plot(1:100, subjective_study_mean,'bx','Linewidth',lw, 'MarkerSize',8);
    xlabel('Image Index');
    ylabel('MOS');
    box on; 
    grid on; 

%% Fig. 6(b)
% Associated histogram of MOS scores. 

MOS_bin =10;
figure; hist(subjective_study_mean)
xlabel('MOS');
ylabel('Number of images')
grid on;

%% Fig. 6(c)
% MOS standard deviation 

std_bin = 10;
figure; hist(subjective_study_std)
xlabel('Std. dev. MOS','FontSize', 16);
ylabel('Number of instance','FontSize', 16);
grid on;
